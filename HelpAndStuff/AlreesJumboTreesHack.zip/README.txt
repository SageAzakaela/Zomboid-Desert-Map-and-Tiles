Enable JUMBO Trees in WorldEd and TileZed

1. Close every existing WorlEd/TileZed processus.
2. Copy the "/Tiles/2x/" folder content in the Tiles directory "/Tiles/2x/" used in WorldEd settings.
3. Copy the "/TileZed/" folder content in the TileZed directory (replace existing file).
4. When generating "Lots" use the "newtiledefinitions.tiles" provided in this archive insteed of the official one.

If you want to add this capacity to an existing map, you have to edit each individual TMX file and add lines:

----- COPY AFTER ONLY AFTER THIS LINE -----
<tileset firstgid="99999" name="jumbo_tree_01" tilewidth="64" tileheight="128">
  <image source="../../../Tiles/jumbo_tree_01.png" width="640" height="1024"/>
</tileset>
----- COPY ONLY BEFORE THIS LINE -----

Do not change the "firstgid", it will be recalculated by WorldEd/TileZed.

Now, in TileZed you have a new "Purple tree" in "jumbo_tree_01" tilesheet.
This "Purple tree" is just a placeholder replaced in game by a working Jumbo Tree.