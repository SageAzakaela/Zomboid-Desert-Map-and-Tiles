function SpawnPoints()
return {
  accountant = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  bookkeeper = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  burglar = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  cashier = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  chef = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  constructionworker = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  cook = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  customerservice = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  doctor = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  drugdealer = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  farmer = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  fastfoodcook = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  fireofficer = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  itworker = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  janitor = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  militaryofficer = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  militarysoldier = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  nurse = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  officeworker = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  parkranger = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  policeofficer = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  salesperson = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  secretary = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  securityguard = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  shopclerk = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  teacher = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  truckdriver = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  unemployed = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  },
  waiter = {
    { worldX = 0, worldY = 0, posX = 261, posY = 260, posZ = 0 }
  }
}
end
