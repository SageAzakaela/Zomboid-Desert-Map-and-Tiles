objects = {
  { name = "", type = "SpawnPoint", x = 261, y = 260, z = 0, width = 1, height = 1, properties = { Professions = "all" } },
  { name = "", type = "Vegitation", x = 0, y = 0, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 300, y = 0, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 600, y = 0, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 0, y = 300, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 300, y = 300, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 600, y = 300, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 0, y = 600, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 300, y = 600, z = 0, width = 300, height = 300 },
  { name = "", type = "Vegitation", x = 600, y = 600, z = 0, width = 300, height = 300 }
}
