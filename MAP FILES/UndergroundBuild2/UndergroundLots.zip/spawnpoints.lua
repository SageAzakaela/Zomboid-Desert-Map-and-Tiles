function SpawnPoints()
return {
  accountant = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  bookkeeper = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  burglar = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  cashier = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  chef = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  constructionworker = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  cook = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  customerservice = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  doctor = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  drugdealer = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  farmer = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  fastfoodcook = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  fireofficer = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  itworker = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  janitor = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  militaryofficer = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  militarysoldier = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  nurse = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  officeworker = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  parkranger = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  policeofficer = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  salesperson = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  secretary = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  securityguard = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  shopclerk = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  teacher = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  truckdriver = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  unemployed = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  },
  waiter = {
    { worldX = 4, worldY = 15, posX = 144, posY = 148, posZ = 0 }
  }
}
end
